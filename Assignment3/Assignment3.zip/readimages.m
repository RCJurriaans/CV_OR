im1 = im2double(imread('boat/img1.pgm'));
im2 = im2double(imread('boat/img2.pgm'));
im3 = im2double(imread('boat/img3.pgm'));
im4 = im2double(imread('boat/img4.pgm'));
im5 = im2double(imread('boat/img5.pgm'));