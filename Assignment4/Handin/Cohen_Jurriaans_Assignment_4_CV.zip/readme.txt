Taco Cohen, 6394590
Robrecht Jurriaans, 5887380

Demo programs are:
opflowdemo.m
modelhousedemo.m
SFMdemo.m
