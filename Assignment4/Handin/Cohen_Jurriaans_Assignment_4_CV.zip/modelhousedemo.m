% 1.3 Demo which runs over all pictures from 'model house/'
% Outputs images to 'model house out/' with tracked points,
% ground truth and a graph for sum of squared error and median error

createMovie()