sphere1 = rgb2gray(im2double(imread('sphere1.ppm')));
sphere2 = rgb2gray(im2double(imread('sphere2.ppm')));
synth1 = im2double(imread('synth1.pgm'));
synth2 = im2double(imread('synth2.pgm'));
