CV_OR
=====

Computer Vision Object Recognition 2012